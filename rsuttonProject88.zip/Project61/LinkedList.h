//################################################## 
// File: LinkedList.h
// Author: Rodrick Sutton 
// Description:  This file contains code for a linked list  
// Date: 5/14/22
//################################################# 

#pragma once

#include <iostream>
#include <vector>
#include <string>

using namespace std;

class LinkedList
{
public:
	string cCity;

	LinkedList(string cityName)
	{
		cCity = cityName;
	}
};
