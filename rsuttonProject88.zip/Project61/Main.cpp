
//################################################## 
// File: Main.cpp 
// Author: Rodrick Sutton
// Description:  This file contains code for testing 
// Date: 5/14/22
//################################################# 

#include <iostream>
#include <vector>
#include <string>
#include "LinkedList.h"
#include "Graph.h"

using namespace std;

int main()
{
	Graph adgGragh(53);
	LinkedList* rCity;
	LinkedList* bCity;


	rCity = new LinkedList("Canyon Lake");
	adgGragh.insert(rCity);
	bCity = new LinkedList("Sun City");
	adgGragh.insert(bCity);
	bCity = new LinkedList("Lake Elsinore");
	adgGragh.insert(bCity);
	bCity = new LinkedList("Murrietta");
	adgGragh.insert(bCity);


	adgGragh.insertEdge(0, 1, 1);
	adgGragh.insertEdge(0, 2, 1);
	adgGragh.insertEdge(1, 3, 1);
	adgGragh.insertEdge(3, 2, 1);


	adgGragh.clearC();
	adgGragh.dfs(rCity);

	cout << endl;


	adgGragh.clearC();


	return 0;
}